com_port = 'COM3';
arb = Arbotix('port',com_port, 'nservos',5);

% Constants
jointSpeed = [50 50 50 50 50]; % Between 0 to 1023. Each increment is 0.111 rpm.
pick_pos = [220.19, 0, -30, -70.2561*pi/180]; % fixed pick-up position.
place_pos = [-128.453 -123.812 -20 -117.94*pi/180]; % Fixed place position.

% Ensure that the pincher moves with the desired speed.
current_pos = arb.getpos();
arb.setpos(current_pos, jointSpeed)

%idle position
idle_pos = [200 0 46 0];
arb = Arbotix('port', com_port, 'nservos', 5);
position = [dh2servo(obtainIK(idle_pos)) 0];
arb.setpos(position, jointSpeed)

% Go to pickup position.
position(1:4) = dh2servo(obtainIK(pick_pos));
arb = Arbotix('port', com_port, 'nservos', 5);
arb.setpos(position, jointSpeed)

% Close pincher.
position(5) = 1.1;
arb = Arbotix('port', com_port, 'nservos', 5);
arb.setpos(position, jointSpeed)

% Go to current height + 100mm.
new_pos = pick_pos;
new_pos(3) = pick_pos(3) + 100;
position(1:4) = dh2servo(obtainIK(new_pos));
arb = Arbotix('port', com_port, 'nservos', 5);
arb.setpos(position, jointSpeed)

% Go above the place position.
new_pos(1:2) = place_pos(1:2);
position(1:4) = dh2servo(obtainIK(new_pos));
arb = Arbotix('port', com_port, 'nservos', 5);
arb.setpos(position, jointSpeed)

% Go to the place position.
position(1:4) = dh2servo(obtainIK(place_pos));
arb = Arbotix('port', com_port, 'nservos', 5);
arb.setpos(position, jointSpeed)

% Open the pincher.
position(5) = 0;
arb = Arbotix('port',com_port, 'nservos',5);
arb.setpos(position, jointSpeed)

% Go above the place position.
position(1:4) = dh2servo(obtainIK(new_pos));
arb = Arbotix('port', com_port, 'nservos', 5);
arb.setpos(position, jointSpeed)

% Return back to idle position.
position = [dh2servo(obtainIK(idle_pos)) 0];
arb = Arbotix('port',com_port, 'nservos',5);
arb.setpos(position, jointSpeed)
