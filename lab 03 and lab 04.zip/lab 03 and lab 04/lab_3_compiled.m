clear;
    %% Create all objects to be used in this file
    % Make Pipeline object to manage streaming
    pipe = realsense.pipeline();
    % Make Colorizer object to prettify depth output
    colorizer = realsense.colorizer();
    % Create a config object to specify configuration of pipeline
    cfg = realsense.config();

    
    %% Set configuration and start streaming with configuration
    % Stream options are in stream.m; These options tap into the various
    % sensors included in the camera
    streamType = realsense.stream('depth');
    % Data format options are in format.m
    formatType = realsense.format('Distance');
    % Enable default depth
    cfg.enable_stream(streamType,formatType);
    % Enable color stream
    streamType = realsense.stream('color');
    formatType = realsense.format('rgb8');
    cfg.enable_stream(streamType,formatType);
    
    % Start streaming on an arbitrary camera with chosen settings
    profile = pipe.start();

    %% Acquire and Set device parameters 
    % Get streaming device's name
    dev = profile.get_device();    
    name = dev.get_info(realsense.camera_info.name);

    % Access Depth Sensor
    depth_sensor = dev.first('depth_sensor');

    % Access RGB Sensor
    rgb_sensor = dev.first('roi_sensor');
    
    % Find the mapping from 1 depth unit to meters, i.e. 1 depth unit =
    % depth_scaling meters.
    depth_scaling = depth_sensor.get_depth_scale();

    % Set the control parameters for the depth sensor
    % See the option.m file for different settable options that are visible
    % to you in the viewer.
    optionType = realsense.option('visual_preset');
    % Set parameters to the midrange preset. See for options:
    % https://intelrealsense.github.io/librealsense/doxygen/rs__option_8h.html#a07402b9eb861d1defe57dbab8befa3ad
    depth_sensor.set_option(optionType,9);

    % optionType = realsense.option('exposure');
    % depth_sensor.set_option(optionType, 625);
    
    % Set manual exposure for RGB sensor
    % optionType = realsense.option('exposure');
    % rgb_sensor.set_option(optionType, 200);

    % Auto Exposure.
    optionType = realsense.option('enable_auto_exposure');
    rgb_sensor.set_option(optionType,1);

    optionType = realsense.option('enable_auto_white_balance');
    rgb_sensor.set_option(optionType,0);    
    
    %% Align the color frame to the depth frame and then get the frames
    % Get frames. We discard the first couple to allow
    % the camera time to settle
    for i = 1:5
        fs = pipe.wait_for_frames();
    end
    
    
    
    % figure
    color_before = fs.get_color_frame();
    
    
    % Stop streaming
    pipe.stop();

    %% Depth Post-processing
    % Select depth frame
    depth = fs.get_depth_frame();
    width = depth.get_width();
    height = depth.get_height();

    
    % Decimation filter of magnitude 2
    % dec = realsense.decimation_filter(2);
    % depth = dec.process(depth);

    % Spatial Filtering
    % spatial_filter(smooth_alpha, smooth_delta, magnitude, hole_fill)
    spatial = realsense.spatial_filter(.5,20,2,0);
    depth_p = spatial.process(depth);
    
    % Hole Filling Filter
    % hole_filter = realsense.hole_filling_filter(2);
    % depth_p = hole_filter.process(depth_p);
    % 
    % color_data = color_before.get_data();
    % im_before = permute(reshape(color_data',[3,color_before.get_width(),color_before.get_height()]),[3 2 1]);
    % imshow(im_before)

    % Temporal Filtering
    % temporal_filter(smooth_alpha, smooth_delta, persistence_control)
    temporal = realsense.temporal_filter(.13,20,3);
    depth_p = temporal.process(depth_p);

    % depth_data = double(depth_p.get_data()) * depth_scaling; 
    % depth_data = reshape(depth_data,[width height]);
    % depth_data = depth_data';
    % 
    % imshow(depth_data)

    % Alignment
    align_to_depth = realsense.align(realsense.stream.depth);
    
    fs = align_to_depth.process(fs);

    %% Color Post-processing
    % Select color frame
    color = fs.get_color_frame();    

    %% Colorize and display depth frame
    % Colorize depth frame
    depth_color = colorizer.colorize(depth_p);

    % Get actual data and convert into a format imshow can use
    % (Color data arrives as [R, G, B, R, G, B, ...] vector)fs
    data = depth_color.get_data();
    img = permute(reshape(data',[3,depth_color.get_width(),depth_color.get_height()]),[3 2 1]);
    
    % figure
    % color_after = fs.get_color_frame();
    % color_data_after = color_before.get_data();
    % im_after = permute(reshape(color_data_after',[3,color_after.get_width(),color_after.get_height()]),[3 2 1]);
    % imshow(im_after)
    % Display image
    % imshow(img);
    % title(sprintf("Colorized depth frame from %s", name));

    %% Display RGB frame
    % Get actual data and convert into a format imshow can use
    % (Color data arrives as [R, G, B, R, G, B, ...] vector)fs
    data2 = color.get_data();
    im = permute(reshape(data2',[3,color.get_width(),color.get_height()]),[3 2 1]);
    % figure
    % imshow(im)
    % Obtaining the x and y coordinates of blocks using the depth values.

    r = im(:, :, 1);
    g = im(:, :, 2);
    b = im(:, :, 3);

    redMask = r - g > 20 & r - b > 40;
    blueMask = b - g > 30 & b - r > 60;
    % yellowMask = g - b > 80 & g - b > 40;
    yellowMask = g - b > 40;
    % greenMask = abs(g - b) > 5 & g - r > 20;
    greenMask = g - r > 20;

    % figure
    % imshow(im)

    % figure
    finalMask = (redMask + greenMask + blueMask + yellowMask);
    bImage = imoverlay(im, finalMask, "k");
    % imshow(bImage)

    % figure
    % imshowpair(redMask, blueMask, "montage");
    depth_data = double(depth_p.get_data()) * depth_scaling; 
    depth_data = reshape(depth_data,[width height]);
    depth_data = depth_data';
    figure
    imshow(depth_data)
    depth_data = depth_data .* (finalMask > 0);
    
    % figure
    % imshow(depth_data) % Rotate the depth image

    % % Display image
    % figure;
    % imshow(im);
    % title(sprintf("Color RGB frame from %s", name));
    % 
    % %% Depth frame without colorizing    
    % % Convert depth values to meters
    % data3 = depth_scaling * double(depth_p.get_data());
    % 
    % %Arrange data in the right image format
    % ig = permute(reshape(data3',[width,height]),[2 1]);
    % 
    % % Scale depth values to [0 1] for display
    % figure;
    % imshow(mat2gray(ig));
    % 
    % 
    % 
    % Detection of top-faces.
    % clear
% load depth_workspace.mat
    
    blue_depth = blueMask .* depth_data;
    mean_blue = mean(depth_data(blue_depth > 0));
    blue_top = imoverlay(im, blueMask .* (blue_depth < mean_blue), "r");
    
    red_depth = redMask .* depth_data;
    mean_red = mean(depth_data(red_depth > 0));
    red_top = imoverlay(im, redMask .* (red_depth < mean_red), "r");
    
    yellow_depth = yellowMask .* depth_data;
    mean_yellow = mean(depth_data(yellow_depth > 0));
    yellow_top = imoverlay(im, yellowMask .* (yellow_depth < mean_yellow), "r");
    
    green_depth = greenMask .* depth_data;
    s_green = sort(green_depth(green_depth > 0));
    l_s = length(s_green);
    mean_green = mean(s_green(int32(l_s/4) : int32(0.75*l_s)));
    green_top = imoverlay(im, greenMask .* (green_depth < mean_green), "r");
    
    X_mask = blueMask .* (blue_depth < mean_blue) + redMask .* (red_depth < mean_red) + yellowMask .* (yellow_depth < mean_yellow) + greenMask .* (green_depth < mean_green);
    X_mask = (X_mask > 0);
    
    X_mask_new = bwpropfilt(X_mask, "Area", 4, "Largest");

    top_color = imoverlay(im, X_mask_new, "r");

    blocksBB = regionprops("table", X_mask_new, "BoundingBox");
    blocksOrientation = regionprops("table", X_mask_new, "Orientation");

    blocksBox = blocksBB.BoundingBox;
    blocksBox = blocksBox';
    hold on
    imshow(top_color)
    rectangle("Position", blocksBox(1:4), "LineWidth", 2, "EdgeColor", "g");
    rectangle("Position", blocksBox(5:8), "LineWidth", 2, "EdgeColor", "g");
    rectangle("Position", blocksBox(9:12), "LineWidth", 2, "EdgeColor", "g");
    rectangle("Position", blocksBox(13:16), "LineWidth", 2, "EdgeColor", "g");
    hold off

    imshow(top_color)
    blocksCorners = regionprops("struct", X_mask_new, "Extrema");
    blockCentroids = regionprops("struct", X_mask_new, "Centroid");
    blockAngles = blocksOrientation.Orientation;
    
    theta = -blockAngles(1);
    b1_centroid = blockCentroids(1).Centroid;
    x = 240 - b1_centroid(1);
    y = 360 - b1_centroid(2);
    z = 1;
    
    T = [cos(theta) -sin(theta) 0   x;
         sin(theta)  cos(theta) 0   y;
         0           0          1   z;
         0           0          0   1];
    
    R = T(1:3, 1:3);
    P = T(1:3, 4);
    T_i = [R',          -R'*P;
           zeros([1 3]),    1]
    
    x2 = 240 - blockCentroids(2).Centroid(1);
    y2 = 360 - blockCentroids(2).Centroid(2);
    
    p = [0; 0; 0; 1];
    pt = T_i * p;
    pt = R * pt(1:3, 1);
    pt = T_i * [x2; y2; 1; 1];
    % new_top_color = imrotate(top_color, -blockAngles(1)); 
    
    hold on
    for i = 1 : length(blocksCorners)
        block = blocksCorners(i).Extrema;
        
        % Rotating corners by additive inverse of the orientation angle of block.
        % theta = blockAngles(i);
        % T_o = [cos(theta) sin(theta);
        %        -sin(theta) cos(theta)];
        % 
        % for j = 1 : length(block)
        %     block(j, :) = (T_o * block(j, :)')';
        % end
    
        corners = [mean(block(1:2, :)); mean(block(3:4, :)); mean(block(5:6, :)); mean(block(7:8, :))];
        % corners = [block(2, :); block(4, :); block(6, :); block(8, :)]; % Take the top-left, top-right, bottom-right, and bottom-left corners.
        scatter(corners(:, 1), corners(:, 2), "w*"); % Plot corner points over the block image.
        % scatter(block(:, 1), block(:, 2), "g*"); All eight corner points
    end
    hold off
    
    


    % rectangle("Position", blocksBox(1:4), "LineWidth", 2, "EdgeColor", "g");
