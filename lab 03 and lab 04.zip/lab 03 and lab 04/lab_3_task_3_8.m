% clear
% load depth_workspace.mat

blue_depth = blueMask .* depth_data;
mean_blue = mean(depth_data(blue_depth > 0));
blue_top = imoverlay(im, blueMask .* (blue_depth < mean_blue), "r");

red_depth = redMask .* depth_data;
mean_red = mean(depth_data(red_depth > 0));
red_top = imoverlay(im, redMask .* (red_depth < mean_red), "r");

yellow_depth = yellowMask .* depth_data;
mean_yellow = mean(depth_data(yellow_depth > 0));
yellow_top = imoverlay(im, yellowMask .* (yellow_depth < mean_yellow), "r");

green_depth = greenMask .* depth_data;
s_green = sort(green_depth(green_depth > 0));
l_s = length(s_green);
mean_green = mean(s_green(int32(l_s/4) : int32(0.75*l_s)));
green_top = imoverlay(im, greenMask .* (green_depth < mean_green), "r");

X_mask = blueMask .* (blue_depth < mean_blue) + redMask .* (red_depth < mean_red) + yellowMask .* (yellow_depth < mean_yellow) + greenMask .* (green_depth < mean_green);
top_color = imoverlay(im, X_mask, "r");

imshow(top_color)