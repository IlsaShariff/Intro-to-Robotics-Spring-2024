
load perception.mat top_color
% load perception.mat im
load perception.mat X_mask_new
load perception.mat blocksOrientation

imshow(top_color)
blocksCorners = regionprops("struct", X_mask_new, "Extrema");
blockCentroids = regionprops("struct", X_mask_new, "Centroid");
blockAngles = blocksOrientation.Orientation;

theta = -blockAngles(1);
b1_centroid = blockCentroids(1).Centroid;
x = 240 - b1_centroid(1);
y = 360 - b1_centroid(2);
z = 1;

T = [cos(theta) -sin(theta) 0   x;
     sin(theta)  cos(theta) 0   y;
     0           0          1   z;
     0           0          0   1];

R = T(1:3, 1:3);
P = T(1:3, 4);
T_i = [R',          -R'*P;
       zeros([1 3]),    1]

x2 = 240 - blockCentroids(2).Centroid(1);
y2 = 360 - blockCentroids(2).Centroid(2);

p = [0; 0; 0; 1];
pt = T_i * p;
pt = R * pt(1:3, 1);
pt = T_i * [x2; y2; 1; 1];
% new_top_color = imrotate(top_color, -blockAngles(1)); 

hold on
for i = 1 : length(blocksCorners)
    block = blocksCorners(i).Extrema;
    
    % Rotating corners by additive inverse of the orientation angle of block.
    % theta = blockAngles(i);
    % T_o = [cos(theta) sin(theta);
    %        -sin(theta) cos(theta)];
    % 
    % for j = 1 : length(block)
    %     block(j, :) = (T_o * block(j, :)')';
    % end

    corners = [mean(block(1:2, :)); mean(block(3:4, :)); mean(block(5:6, :)); mean(block(7:8, :))];
    % corners = [block(2, :); block(4, :); block(6, :); block(8, :)]; % Take the top-left, top-right, bottom-right, and bottom-left corners.
    scatter(corners(:, 1), corners(:, 2), "w*"); % Plot corner points over the block image.
    % scatter(block(:, 1), block(:, 2), "g*"); All eight corner points
end
hold off




% rectangle("Position", blocksBox(1:4), "LineWidth", 2, "EdgeColor", "g");
