/* Include files */

#include "task_1_cgxe.h"
#include "m_YwfR3zyO6cwdjVsVxtASRF.h"

unsigned int cgxe_task_1_method_dispatcher(SimStruct* S, int_T method, void
  * data)
{
  if (ssGetChecksum0(S) == 2802863562 &&
      ssGetChecksum1(S) == 176241166 &&
      ssGetChecksum2(S) == 1113533624 &&
      ssGetChecksum3(S) == 2640693142) {
    method_dispatcher_YwfR3zyO6cwdjVsVxtASRF(S, method, data);
    return 1;
  }

  return 0;
}
