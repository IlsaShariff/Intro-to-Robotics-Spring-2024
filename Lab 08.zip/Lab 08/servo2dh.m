function dhJointAngles = servo2dh(jointAngles)
    dhJointAngles = jointAngles;
    dhJointAngles(2) = dhJointAngles(2) +pi /2;
end