im_width = 640;
im_height = 480;

fov_x = deg2rad(69);
fov_y = deg2rad(54);
u0 = im_width/2;
v0 = im_height/2;

[depth_image, T_mats] = detectCubes();

[~, ~, nMats] = size(T_mats);

for i = 1:nMats
    T = T_mats(:, :, i);
    u = round(T(1, 4));
    v = round(T(2, 4));
    z = depth_image(u+u0, v+v0)
    fx = tan(fov_x/2)/z;
    fy = tan(fov_y/2)/z;
    x = (u/u0)*z/fx * 1000
    y = (v/v0)*z/fy * 1000
    phi = -50*pi/180;
    z = -30;
    
    image_angle = deg2rad(90);
    R = [cos(image_angle) -sin(image_angle);
         sin(image_angle)  cos(image_angle)];
    p = R * [x; -y]

    pos = [p(1) p(2) z phi]
    pincher_control(pos)
end
% x = u-u0