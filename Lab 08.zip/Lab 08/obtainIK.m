function jointVaribales = obtainIK(dPose)
    x = dPose(1);
    y = dPose(2);
    z = dPose(3);
    phi = dPose(4);

    % Link lengths and link offsets (in mm).
    d1 = 46;
    l2 = 109.6;
    l3 = 109.6;
    l4 = 56.46;

    r = sqrt(x^2 + y^2); % --> x
    s = z - d1; % --> y

    a = r - l4*cos(phi);
    b = s - l4*sin(phi);

    % alpha = acos((a^2 + b^2 + l2^2 - l3^2 )/(2*l2*sqrt(a^2 + b^2)))
    cos_alpha = (a^2 + b^2 + l2^2 - l3^2 )/(2*l2*sqrt(a^2 + b^2));
    alpha = acos(round(cos_alpha, 4)); % Round cos_alpha to 4 decimal digits in order to avoid floating point errors.
    % sin_alpha = sqrt(1 - cos_alpha^2)
   
    % alpha_01 = atan2(sin_alpha, cos_alpha)
    % alpha_02 = atan2(-sin_alpha, cos_alpha); % For backward shoulder.
    gamma = atan2(b, a);
    cos_beta = (l2^2 + l3^2 -a^2 -b^2)/(2*l2*l3);
    beta = acos(round(cos_beta, 4)); % Round cos_alpha to 4 decimal digits in order to avoid floating point errors.

    % Case 01 (Elbow Down).
    theta1_01 = atan2(y, x);
    theta1_02 = gamma - alpha;
    theta1_03 = pi - beta;
    theta1_04 = phi - theta1_02 - theta1_03;
    elbow_down = [theta1_01 theta1_02 theta1_03 theta1_04];

    % Case 02 (Elbow Up).
    theta2_01 = theta1_01;
    theta2_02 = gamma + alpha;
    theta2_03 = pi + beta;
    theta2_04 = phi - theta2_02 - theta2_03;
    elbow_up = [theta2_01 theta2_02 theta2_03 theta2_04];
    jointVaribales = elbow_up;

    % Case 03 (Elbow Down Backward).
    theta3_01 = theta1_01 + pi;
    theta3_02 = pi - (gamma - alpha);
    theta3_03 = -(pi - beta);
    theta3_04 = phi - theta3_02 - theta3_03;
    elbow_down_backward = [theta3_01 theta3_02 theta3_03 theta3_04];

    % Case 04 (Elbow Up Backward).
    theta4_01 = theta1_01 + pi;
    theta4_02 = pi - (gamma + alpha);
    theta4_03 = -(pi + beta);
    theta4_04 = phi - theta4_02 - theta4_03;
    elbow_up_backward = [theta4_01 theta4_02 theta4_03 theta4_04];
end