function [depth_data, T_mats] = detectCubes()
%% Setup.
    % Create all objects to be used in this file
    % Make Pipeline object to manage streaming
    pipe = realsense.pipeline();
    % Create a config object to specify configuration of pipeline
    cfg = realsense.config();
    
    %% Set configuration and start streaming with configuration
    % Stream options are in stream.m; These options tap into the various
    % sensors included in the camera
    streamType = realsense.stream('depth');
    % Data format options are in format.m
    formatType = realsense.format('Distance');
    % Enable default depth
    cfg.enable_stream(streamType,formatType);
    % Enable color stream
    streamType = realsense.stream('color');
    formatType = realsense.format('rgb8');
    cfg.enable_stream(streamType,formatType);
    
    % Start streaming on an arbitrary camera with chosen settings
    profile = pipe.start();

    %% Acquire and Set device parameters 
    % Get streaming device's name
    dev = profile.get_device();    
    name = dev.get_info(realsense.camera_info.name);

    % Access Depth Sensor
    depth_sensor = dev.first('depth_sensor');

    % Access RGB Sensor
    rgb_sensor = dev.first('roi_sensor');
    
    % Find the mapping from 1 depth unit to meters, i.e. 1 depth unit =
    % depth_scaling meters.
    depth_scaling = depth_sensor.get_depth_scale();

    % Set the control parameters for the depth sensor
    optionType = realsense.option('visual_preset');
    depth_sensor.set_option(optionType,9);
    
    % Set manual exposure for RGB sensor
    % optionType = realsense.option('exposure');
    % rgb_sensor.set_option(optionType, 200);

    % Auto Exposure.
    optionType = realsense.option('enable_auto_exposure');
    rgb_sensor.set_option(optionType,1);
    
    % Auto White Balance.
    optionType = realsense.option('enable_auto_white_balance');
    rgb_sensor.set_option(optionType,0);    
    
    %% Get color frames.
    % Get frames and discard the first couple to allow
    % the camera time to settle
    for i = 1:5
        fs = pipe.wait_for_frames();
    end
    
    % Stop streaming
    pipe.stop();

    %% Depth Post-processing
    % Select depth frame
    depth = fs.get_depth_frame();
    width = depth.get_width();
    height = depth.get_height();

    
    % Decimation filter of magnitude 2
    % dec = realsense.decimation_filter(2);
    % depth = dec.process(depth);

    % Spatial Filtering
    % spatial_filter(smooth_alpha, smooth_delta, magnitude, hole_fill)
    spatial = realsense.spatial_filter(.5,20,2,0);
    depth_p = spatial.process(depth);
    
    % Hole Filling Filter
    % hole_filter = realsense.hole_filling_filter(2);
    % depth_p = hole_filter.process(depth_p);
    % 
    % color_data = color_before.get_data();
    % im_before = permute(reshape(color_data',[3,color_before.get_width(),color_before.get_height()]),[3 2 1]);
    % imshow(im_before)

    % Temporal Filtering
    % temporal_filter(smooth_alpha, smooth_delta, persistence_control)
    temporal = realsense.temporal_filter(.13,20,3);
    depth_p = temporal.process(depth_p);

    %% Depth Alignment
    % align_to_depth = realsense.align(realsense.stream.depth);
    align_to_depth = realsense.align(realsense.stream.depth);
    fs = align_to_depth.process(fs);

    %% Color Post-processing
    % obtain and convert color image to Height x Width x 3

    % Get color frame
    color = fs.get_color_frame();    

    % Get actual data and convert into a format imshow can use
    % (Color data arrives as [R, G, B, R, G, B, ...] vector)fs
    data2 = color.get_data();
    % im = permute(reshape(data2',[3,color.get_width(),color.get_height()]),[3 2 1]);
    im = permute(reshape(data2',[3,width,height]),[3 2 1]);

    %% Generate Masks.

    % Extract Color Channels.
    r = im(:, :, 1);
    g = im(:, :, 2);
    b = im(:, :, 3);

    % Generate masks for available colors.
    redMask = r - g > 20 & r - b > 40;
    blueMask = b - g > 30 & b - r > 60;
    yellowMask = g - b > 40;
    greenMask = g - r > 20;

    % figure
    % imshow(im)
    % title("Depth Aligned Color Image")
    % 
    % figure
    % imshow(redMask | blueMask | yellowMask | greenMask)
    % title("Original Superimposed Masks")
    % 
    % figure
    % subplot 221; imshow(blueMask); title("Blue Mask")
    % subplot 222; imshow(redMask); title("Red Mask")
    % subplot 223; imshow(yellowMask); title("Yellow Mask")
    % subplot 224; imshow(greenMask); title("Green Mask")

    %% Scale depth values to meters.
    depth_data = double(depth_p.get_data()) * depth_scaling; 
    depth_data = reshape(depth_data,[width height]);
    depth_data = depth_data';

    % figure
    % imshow(depth_data)
    % title("Depth Image")
    
    %% Depth segmentation.

    % Use average height of cubes as threshold.

    % blue_depth = depth_data(blueMask);
    % blue_top_mask = blueMask & (depth_data < mean(blue_depth));
    % blue_top = imoverlay(im, blue_top_mask, "r");
    % 
    % red_depth = depth_data(redMask);
    % red_top_mask = redMask & (depth_data < mean(red_depth));
    % red_top = imoverlay(im, red_top_mask, "r");
    % 
    % yellow_depth = depth_data(yellowMask);
    % yellow_top_mask = yellowMask & (depth_data < mean(yellow_depth));
    % yellow_top = imoverlay(im, yellow_top_mask, "r");
    % 
    % green_depth = depth_data(greenMask);
    % green_top_mask = greenMask & (depth_data < mean(green_depth));
    % green_top = imoverlay(im, green_top_mask, "r");

    % Use manual threshold.

    blue_top_mask = blueMask & (depth_data < 0.66);
    blue_top = imoverlay(im, blue_top_mask, "r");

    red_top_mask = redMask & (depth_data < 0.7);
    red_top = imoverlay(im, red_top_mask, "r");

    yellow_top_mask = yellowMask & (depth_data < 0.66);
    yellow_top = imoverlay(im, yellow_top_mask, "r");

    green_top_mask = greenMask & (depth_data < 0.66);
    green_top = imoverlay(im, green_top_mask, "r");


    % figure
    % subplot 221; imshow(blue_top); title("Blue Mask")
    % subplot 222; imshow(red_top); title("Red Mask")
    % subplot 223; imshow(yellow_top); title("Yellow Mask")
    % subplot 224; imshow(green_top); title("Green Mask")
    
    % Superimpose masks.
    finalMask = (blue_top_mask | red_top_mask | yellow_top_mask...
        | green_top_mask);

    

    % Extract only cube objects that have been selected using mask.
    % Disregard noise.
    cubesMask = bwpropfilt(finalMask, "Area", [100 inf]);
    % figure
    % imshow(cubesMask)
    % title("Superimposed Masks")

    top_color = imoverlay(im, cubesMask, "r");

    figure
    imshow(top_color)
    title("Masked Cubes")
    %% Pose Estimation.
    % Cubes Bounding Boxes.
    cubesBB = regionprops("table", cubesMask, "BoundingBox");
    cubesBox = cubesBB.BoundingBox;
    cubesBox = cubesBox';
    % Number of columns is the number of cubes.
    [nVals, nCubes] = size(cubesBox); 

    % Display Cubes with Bounding Boxes.
    % figure
    % imshow(top_color)
    % title("Cubes with Bounding Boxes")
    % hold on
    % for i = 1:4:nCubes*nVals
    %     rectangle("Position", cubesBox(i:i+3), "LineWidth", 2,...
    %         "EdgeColor", "g");     
    % end
    % hold off
    
    % Obtain corners of the cubes.
    % blocksCorners = regionprops("struct", cubesMask, "Extrema");
    blockCentroids = regionprops("struct", cubesMask, "Centroid");
    blocksOrientation = regionprops("table", cubesMask, "Orientation");
    blockAngles = blocksOrientation.Orientation;

    % Display Cubes with Corners.
    % figure
    % imshow(top_color)
    % title("Cubes with Corners")
    % hold on
    % for i = 1 : nCubes
    %     block = blocksCorners(i).Extrema;
    %     % There are 8 corners given by regionprops, therefore, I take the
    %     % mean of two extreme points close to each other to find a more
    %     % suitable corner point since the masks arent always rectangular.
    % 
    %     corners = [mean(block(1:2, :)); mean(block(3:4, :)); ...
    %         mean(block(5:6, :)); mean(block(7:8, :))];
    %      % Plot corner points over the block image.
    %     scatter(corners(:, 1), corners(:, 2), "w*");
    % end
    % hold off

    % Transformation Matrices for all cubes.
    T_mats = zeros([4 4 nCubes]);
    for i = 1:nCubes
        theta = blockAngles(i);
        cube_i_centroid = blockCentroids(i).Centroid;
        % Shift base frame from top corner to center of the image.
        x = cube_i_centroid(1) - double(width)/2;
        y = cube_i_centroid(2) - double(height)/2;
        z = 0;
    
        % Cube frame transformation matrix.
        % Rotation matrix is for rotation about z-axis, which is what is
        % measured by regionprops.
        T = [cos(theta) -sin(theta) 0   x;
             sin(theta)  cos(theta) 0   y;
             0           0          1   z;
             0           0          0   1];

        T_mats(:, :, i) = T;
    
        % R = T(1:3, 1:3);
        % P = T(1:3, 4);
        % T_i = [R',          -R'*P;
        %        zeros([1 3]),    1];
    end
end